#! /bin/sh

#export LDFLAGS="$LDFLAGS -L$(pwd)/../../../library/zlib/zlib-1.2.3/lib -L$(pwd)/../../../library/jpeg/jpeg-7/lib"
#export CFLAGS="$CFLAGS -I$(pwd)/../../../library/zlib/zlib-1.2.3/include -I$(pwd)/../../../library/jpeg/jpeg-7/include"
#make clean
#make distclean

#export CROSS_COMPILE="/mtkoss/gnuarm/soft_4.5.1_2.6.27_arm11-rhel4/i686/bin/armv6z-mediatek451_001_soft-linux-gnueabi-"
export CROSS_COMPILE="/mtkoss/gnuarm/vfp_4.5.1_2.6.27_cortex-a9-rhel4/i686/bin/armv7a-mediatek451_001_vfp-linux-gnueabi-"

export CC=${CROSS_COMPILE}gcc 

export LD=${CROSS_COMPILE}ld 

#sh ./configure --host=/mtkoss/gnuarm/soft_4.5.1_2.6.27_arm11-rhel4/i686/bin/armv6z-mediatek451_001_soft-linux-gnueabi \
#--target=/mtkoss/gnuarm/soft_4.5.1_2.6.27_arm11-rhel4/i686/bin/armv6z-mediatek451_001_soft-linux-gnueabi \
#--prefix=$(pwd)/../../../library/webp/webp-0.2.1
	
#./configure --prefix=/proj/mtk94121/p4/ws_jiyang.zou_nflx/DTV/DEV_BR/e_IDTV0801_LINUX_002179_26_001_55_NFLX32_BR/vm_linux/oss/library/gnuarm-4.5.1_vfp_ca9/webp/0.2.1/pre-install --build=armv6z-mediatek451_001_soft-linux-gnueabi --host=`${CC} -dumpmachine` --with-pnglibdir=/proj/mtk94121/p4/ws_jiyang.zou_nflx/DTV/PROD_BR/DTV_X_IDTV0801/vm_linux/oss/library/gnuarm-4.5.1_vfp_ca9/png/1.2.43/pre-install/lib --with-pngincludedir=/proj/mtk94121/p4/ws_jiyang.zou_nflx/DTV/PROD_BR/DTV_X_IDTV0801/vm_linux/oss/library/gnuarm-4.5.1_vfp_ca9/png/1.2.43/pre-install/include --with-tifflibdir=/dev/null --with-jpeglibdir=/proj/mtk94121/p4/ws_jiyang.zou_nflx/DTV/PROD_BR/DTV_X_IDTV0801/vm_linux/oss/library/gnuarm-4.5.1_vfp_ca9/jpeg/6b/pre-install/lib --with-jpegincludedir=/proj/mtk94121/p4/ws_jiyang.zou_nflx/DTV/PROD_BR/DTV_X_IDTV0801/vm_linux/oss/library/gnuarm-4.5.1_vfp_ca9/jpeg/6b/pre-install/include
./configure --prefix=/proj/mtk94121/p4/ws_jiyang.zou_nflx/DTV/DEV_BR/e_IDTV0801_LINUX_002179_26_001_55_NFLX32_BR/vm_linux/oss/library/gnuarm-4.5.1_vfp_ca9/webp/0.2.1/pre-install --build=armv7a-mediatek451_001_vfp-linux-gnueabi --host=`${CC} -dumpmachine` --with-pnglibdir=/proj/mtk94121/p4/ws_jiyang.zou_nflx/DTV/PROD_BR/DTV_X_IDTV0801/vm_linux/oss/library/gnuarm-4.5.1_vfp_ca9/png/1.2.43/pre-install/lib --with-pngincludedir=/proj/mtk94121/p4/ws_jiyang.zou_nflx/DTV/PROD_BR/DTV_X_IDTV0801/vm_linux/oss/library/gnuarm-4.5.1_vfp_ca9/png/1.2.43/pre-install/include --with-tifflibdir=/dev/null --with-jpeglibdir=/proj/mtk94121/p4/ws_jiyang.zou_nflx/DTV/PROD_BR/DTV_X_IDTV0801/vm_linux/oss/library/gnuarm-4.5.1_vfp_ca9/jpeg/6b/pre-install/lib --with-jpegincludedir=/proj/mtk94121/p4/ws_jiyang.zou_nflx/DTV/PROD_BR/DTV_X_IDTV0801/vm_linux/oss/library/gnuarm-4.5.1_vfp_ca9/jpeg/6b/pre-install/include	  
make
make install