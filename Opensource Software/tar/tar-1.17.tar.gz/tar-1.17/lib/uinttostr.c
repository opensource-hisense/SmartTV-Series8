#define inttostr uinttostr
#define inttype unsigned int
#include "inttostr.c"
