static char SNAPSHOT[] = "s20101006";
